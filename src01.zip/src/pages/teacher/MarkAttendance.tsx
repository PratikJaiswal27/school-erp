import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { getISTNow, getISTDate, getISTTimeString, formatISTTime } from '../../lib/utils';
import ConfirmModal from '../../components/ConfirmModal';
import Toast from '../../components/Toast';

interface Student {
  id: string;
  name: string;
  roll_number: string;
  profile_image: string;
}

interface ClassInfo {
  id: string;
  name: string;
}

const MarkAttendance: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const classIdFromUrl = searchParams.get('class');
  const [assignedClasses, setAssignedClasses] = useState<ClassInfo[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>(classIdFromUrl || '');
  const [students, setStudents] = useState<Student[]>([]);
  const [attendance, setAttendance] = useState<{ [studentId: string]: 'present' | 'absent' }>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const [attendanceStartTime, setAttendanceStartTime] = useState<string>('07:00');
  const [existingAttendance, setExistingAttendance] = useState<{ [studentId: string]: string }>({});
  const [showOverrideModal, setShowOverrideModal] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // Fetch assigned classes for the teacher
  useEffect(() => {
    if (!user?.teacher_id) return;
    const fetchClasses = async () => {
      const { data, error } = await supabase
        .from('class_attendance_teacher')
        .select('class_id, classes:class_id(name)')
        .eq('teacher_id', user.teacher_id);
      if (!error && data) {
        const classes = data.map(c => ({
          id: c.class_id,
          name: c.classes?.name,
        }));
        setAssignedClasses(classes);
        // If no class selected yet and we have classes, optionally select first
        if (!selectedClassId && classes.length > 0) {
          setSelectedClassId(classes[0].id);
        }
      }
    };
    fetchClasses();
  }, [user]);

  // Fetch data when selected class changes
  useEffect(() => {
    if (!selectedClassId) return;
    fetchSettingsAndCheck();
    fetchStudents();
    fetchExistingAttendance();
  }, [selectedClassId]);

  const fetchSettingsAndCheck = async () => {
    const { data: settings, error } = await supabase
      .from('school_settings')
      .select('attendance_start_time')
      .single();
    if (error) {
      console.error('Error fetching settings:', error);
      setBlocked(false);
      return;
    }
    if (settings) {
      setAttendanceStartTime(settings.attendance_start_time);
      const now = getISTNow();
      const [hour, minute] = settings.attendance_start_time.split(':').map(Number);
      const startToday = new Date(now);
      startToday.setHours(hour, minute, 0);
      setBlocked(now < startToday);
    }
  };

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('students')
        .select('id, name, roll_number, profile_image')
        .eq('class_id', selectedClassId)
        .order('roll_number');
      if (error) throw error;
      if (data) {
        setStudents(data);
        const initial: { [key: string]: 'present' | 'absent' } = {};
        data.forEach(s => { initial[s.id] = 'present'; });
        setAttendance(initial);
      }
    } catch (err: any) {
      console.error('Error fetching students:', err);
      setToast({ message: err.message || 'Failed to load students', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const fetchExistingAttendance = async () => {
    const today = getISTDate();
    const { data, error } = await supabase
      .from('attendance')
      .select('student_id, status')
      .eq('class_id', selectedClassId)
      .eq('date', today);
    if (error) {
      console.error('Error fetching existing attendance:', error);
    } else if (data) {
      const existing: { [key: string]: string } = {};
      data.forEach(rec => { existing[rec.student_id] = rec.status; });
      setExistingAttendance(existing);
    }
  };

  const handleSave = async (override = false) => {
    if (!selectedClassId) return;
    setSaving(true);
    const today = getISTDate();
    const updates = [];

    for (const student of students) {
      const status = attendance[student.id];
      if (!status) continue;

      const existing = existingAttendance[student.id];
      if (existing && !override) continue;

      if (existing) {
        updates.push(
          supabase
            .from('attendance')
            .update({
              status,
              updated_at: new Date().toISOString(),
              edited_by_principal: false,
            })
            .eq('student_id', student.id)
            .eq('date', today)
        );
      } else {
        updates.push(
          supabase
            .from('attendance')
            .insert({
              student_id: student.id,
              class_id: selectedClassId,
              date: today,
              status,
              marked_by: user?.teacher_id,
              edited_by_principal: false,
            })
        );
      }
    }

    try {
      await Promise.all(updates);
      setToast({ message: 'Attendance saved successfully', type: 'success' });
      await fetchExistingAttendance(); // refresh to show read-only
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    } finally {
      setSaving(false);
      setShowOverrideModal(false);
    }
  };

  const handleSaveClick = () => {
    const hasExisting = Object.keys(existingAttendance).length > 0;
    if (hasExisting) {
      setShowOverrideModal(true);
    } else {
      handleSave(false);
    }
  };

  // If no assigned classes, show message
  if (assignedClasses.length === 0) {
    return (
      <div className="container mt-5">
        <div className="alert alert-warning">You have no classes assigned.</div>
      </div>
    );
  }

  if (blocked) {
    const startTimeFormatted = formatISTTime(attendanceStartTime);
    const currentTime = formatISTTime(getISTTimeString());
    return (
      <div className="container mt-5">
        <div className="alert alert-warning">
          Attendance opens at {startTimeFormatted}. Current time: {currentTime}.
        </div>
      </div>
    );
  }

  if (loading) return <div className="text-center mt-5">Loading...</div>;

  const hasExistingToday = Object.keys(existingAttendance).length > 0;
  if (hasExistingToday && !showOverrideModal) {
    return (
      <div className="container py-4">
        <h2>Attendance Already Marked Today</h2>
        <div className="mb-3">
          <label>Class</label>
          <select
            className="form-select"
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
          >
            {assignedClasses.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div className="table-responsive">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>Student</th>
                <th>Roll No</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {students.map(student => (
                <tr key={student.id}>
                  <td>{student.name}</td>
                  <td>{student.roll_number}</td>
                  <td>
                    <span className={`badge ${existingAttendance[student.id] === 'present' ? 'bg-success' : 'bg-danger'}`}>
                      {existingAttendance[student.id] === 'present' ? 'Present' : 'Absent'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-4">
      <h2>Mark Attendance</h2>
      <div className="mb-3">
        <label>Select Class</label>
        <select
          className="form-select"
          value={selectedClassId}
          onChange={(e) => setSelectedClassId(e.target.value)}
        >
          {assignedClasses.map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>
      <div className="table-responsive">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Photo</th>
              <th>Name</th>
              <th>Roll No</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {students.map(student => (
              <tr key={student.id}>
                <td>
                  {student.profile_image ? (
                    <img src={student.profile_image} alt={student.name} style={{ width: 40, height: 40, borderRadius: '50%' }} />
                  ) : (
                    <div className="avatar-placeholder" style={{ width: 40, height: 40, borderRadius: '50%', background: '#ccc', display: 'inline-block' }}></div>
                  )}
                </td>
                <td>{student.name}</td>
                <td>{student.roll_number}</td>
                <td>
                  <div className="btn-group" role="group">
                    <button
                      type="button"
                      className={`btn btn-sm ${attendance[student.id] === 'present' ? 'btn-success' : 'btn-outline-success'}`}
                      onClick={() => setAttendance({ ...attendance, [student.id]: 'present' })}
                    >
                      Present
                    </button>
                    <button
                      type="button"
                      className={`btn btn-sm ${attendance[student.id] === 'absent' ? 'btn-danger' : 'btn-outline-danger'}`}
                      onClick={() => setAttendance({ ...attendance, [student.id]: 'absent' })}
                    >
                      Absent
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button className="btn btn-primary" onClick={handleSaveClick} disabled={saving}>
        {saving ? 'Saving...' : 'Save Attendance'}
      </button>

      <ConfirmModal
        show={showOverrideModal}
        onClose={() => setShowOverrideModal(false)}
        onConfirm={() => handleSave(true)}
        title="Override Attendance"
        message="Attendance has already been marked for this class today. Do you want to override it?"
      />

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
};

export default MarkAttendance;